import sysconfig

from pprint import pprint
pprint(sysconfig.get_config_vars())
